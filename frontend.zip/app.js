import React, { useState, useEffect } from 'react';
import UnlockStream from './components/UnlockStream';
import ChannelSwitcher from './components/ChannelSwitcher';

const PlayerScreen = () => {
  const [streamUrl, setStreamUrl] = useState('/streams/channel_01/index.m3u8');

  return (
    <div className="flex flex-col md:flex-row w-full min-h-screen">
      <div className="md:w-1/4 w-full p-4 bg-gray-900">
        <ChannelSwitcher onChannelSelect={setStreamUrl} />
      </div>
      <div className="md:w-3/4 w-full flex justify-center items-center bg-black">
        <video
          controls
          autoPlay
          className="w-full max-w-6xl h-auto"
          src={streamUrl}
          type="application/x-mpegURL"
        />
      </div>
    </div>
  );
};

function App() {
  const [accessGranted, setAccessGranted] = useState(false);

  useEffect(() => {
    const sessionId = new URLSearchParams(window.location.search).get("session_id");
    if (sessionId) {
      fetch(`https://your-backend.com/api/verify-session?session_id=${sessionId}`)
        .then(res => res.json())
        .then(data => {
          if (data.access) setAccessGranted(true);
        });
    }
  }, []);

  return (
    <div className="bg-black text-white min-h-screen">
      {accessGranted ? (
        <PlayerScreen />
      ) : (
        <UnlockStream setAccessGranted={setAccessGranted} />
      )}
    </div>
  );
}

export default App;
