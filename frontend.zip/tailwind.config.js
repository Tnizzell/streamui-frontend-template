/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
      "./index.html",
      "./app.js",
      "./components/**/*.{js,jsx}",
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  