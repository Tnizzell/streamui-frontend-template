import React, { useState, useEffect } from 'react';
import { supabase } from '../utils/supabaseClient';
import UnlockStream from './components/UnlockStream';
import WatchStream from './components/WatchStream';

function App() {
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginVisible, setLoginVisible] = useState(false);
  const [mode, setMode] = useState('login');
  const [isPremium, setIsPremium] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        setSession(data.session);
        checkPremium(data.session.user.email);
      }
    });

    supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        checkPremium(session.user.email);
      }
    });
  }, []);

  const checkPremium = async (email) => {
    if (!email) return;
    const { data } = await supabase
      .from('stream_users')
      .select('is_premium')
      .eq('email', email)
      .single();

    if (!data) {
      await supabase.from('stream_users').upsert(
        { email, is_premium: false },
        { onConflict: 'email' }
      );
    } else {
      setIsPremium(data.is_premium);
    }
  };

  const handleAuth = async () => {
    if (isLoading) return;
    setIsLoading(true);

    try {
      let response;

      if (mode === 'signup') {
        response = await supabase.auth.signUp({ email, password });
      } else {
        response = await supabase.auth.signInWithPassword({ email, password });
      }

      const { error } = response;

      if (error) {
        if (error.message.includes('User already registered') && mode === 'signup') {
          alert('You already have an account. Try logging in instead.');
          setMode('login');
        } else {
          alert(error.message);
        }
        return;
      }

      if (mode === 'signup') {
        alert('Signup successful! Check your email for confirmation before logging in.');
      }

      const { data: freshSession } = await supabase.auth.getSession();
      if (freshSession?.session) {
        setSession(freshSession.session);
        checkPremium(email);
      }
    } catch (err) {
      console.error('Unexpected auth error:', err.message);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!session && loginVisible) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col justify-center items-center space-y-4 px-4">
        <h1 className="text-2xl font-bold">
          {mode === 'signup' ? 'Create an account' : 'Login to continue'}
        </h1>
        <input
          type="email"
          placeholder="Email"
          className="px-4 py-2 text-black rounded-md w-full max-w-xs"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="px-4 py-2 text-black rounded-md w-full max-w-xs"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button
          onClick={handleAuth}
          disabled={isLoading}
          className={`px-6 py-2 rounded-md font-medium ${
            isLoading ? 'bg-gray-600 cursor-not-allowed' : 'bg-violet-600 hover:bg-violet-700'
          }`}
        >
          {isLoading ? 'Loading...' : mode === 'signup' ? 'Sign Up' : 'Login'}
        </button>
        <p
          onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')}
          className="text-sm underline cursor-pointer mt-2 text-gray-400"
        >
          {mode === 'signup' ? 'Already have an account? Login' : 'Need an account? Sign up'}
        </p>
      </div>
    );
  }

  return (
    <div className="relative bg-black text-white min-h-screen w-full overflow-hidden">
      <div className="absolute top-0 w-full overflow-hidden">
        <div className="animate-scroll-left whitespace-nowrap text-sm sm:text-md text-gray-300 py-2 bg-[#111] uppercase tracking-wider font-medium">
          Now Streaming: CyberTokyo | Warriors of the Deep | The Hollow Signal | Project Leviathan | Alien Run | Retro Crimes | BloodScript
        </div>
      </div>

      {!session && !loginVisible && (
        <button
          onClick={() => setLoginVisible(true)}
          className="absolute top-4 right-4 bg-violet-600 hover:bg-violet-700 px-4 py-2 rounded-md font-medium"
        >
          Login
        </button>
      )}

      <div className="flex flex-col justify-center items-center h-full px-4 mt-32 mb-32">
        {session ? (
          isPremium ? <WatchStream /> : <UnlockStream session={session} setAccessGranted={() => setIsPremium(true)} />
        ) : (
          <UnlockStream setAccessGranted={() => null} />
        )}
      </div>

      <div className="absolute bottom-0 w-full overflow-hidden">
        <div className="animate-scroll-right whitespace-nowrap text-sm sm:text-md text-gray-400 py-2 bg-[#111] font-light italic">
          Sponsored by: HyperByte | Drift Supply Co. | EDGECAST | MAGLEV Tees | Vault Automotive | X1 Studios | HostBunker
        </div>
      </div>
    </div>
  );
}

export default App;
