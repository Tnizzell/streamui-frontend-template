import React, { useEffect, useRef } from "react";
import Hls from "hls.js";

const WatchStream = () => {
  const videoRef = useRef(null);

  useEffect(() => {
    const video = videoRef.current;
    const hls = new Hls();

    hls.loadSource("https://moiptvhls-i.akamaihd.net/hls/live/652818/videotv/playlist.m3u8");
    hls.attachMedia(video);

    return () => {
      hls.destroy();
    };
  }, []);

  return (
    <div className="w-full max-w-4xl px-4">
      <video
        ref={videoRef}
        controls
        autoPlay
        className="w-full h-auto bg-black"
      />
    </div>
  );
};

export default WatchStream;
