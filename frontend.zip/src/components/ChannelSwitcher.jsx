// frontend/components/ChannelSwitcher.jsx
import React, { useState, useEffect } from 'react';

const ChannelSwitcher = ({ onChannelSelect }) => {
  const [channels, setChannels] = useState([]);

  useEffect(() => {
    fetch('/api/channels')
      .then(res => res.json())
      .then(data => setChannels(data));
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-white text-lg mb-2">Live Channels</h2>
      <ul className="space-y-2">
        {channels.map(channel => (
          <li key={channel.id}>
            <button
              className="bg-gray-800 hover:bg-gray-700 text-white py-2 px-4 rounded w-full text-left"
              onClick={() => onChannelSelect(channel.url)}
            >
              {channel.title}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ChannelSwitcher;
