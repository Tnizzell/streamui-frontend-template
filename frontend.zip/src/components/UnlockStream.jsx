import React from 'react';

export default function UnlockStream({ setAccessGranted, session }) {
  const handleCheckout = async (mode = 'payment') => {
    if (!session?.user?.email) {
      return alert('⚠️ Please log in or sign up before unlocking the stream.');
    }

    const res = await fetch("https://protective-miracle-production-4ed5.up.railway.app/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode }),
    });

    const data = await res.json();
    window.location.href = data.url;
  };

  return (
    <div className="text-center space-y-6 mt-12">
      <h1 className="text-3xl font-bold text-white">Unlock the Stream</h1>
      <button
        onClick={() => handleCheckout("payment")}
        className="bg-blue-600 px-5 py-2 rounded-md text-white font-medium hover:bg-blue-700"
      >
        One-Time Access – $5.00
      </button>
      <button
        onClick={() => handleCheckout("subscription")}
        className="bg-green-600 px-5 py-2 rounded-md text-white font-medium hover:bg-green-700 ml-4"
      >
        Monthly Sub – $9.99
      </button>
    </div>
  );
}
